#ifndef __BASIC_CUSTOMCODE_DEMO_LIB_H
#define __BASIC_CUSTOMCODE_DEMO_LIB_H

/* Mathworks Data Types */
#include "rtwtypes.h"

void output_customcodelib(boolean_T in1, uint8_T in2, boolean_T in3, uint8_T *out1);

#endif